#include "Empleado.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "ArrayList.h"

void em_calcularSueldo(void* p)
{
    int horas,extras,extrasalcien,auxSueldo;
    Empleado* emp;
    emp=(Empleado*)p;
    if(emp->horasTrabajadas <=176)
    {
        auxSueldo=emp->horasTrabajadas*180;
        emp->sueldo=auxSueldo;
        //setterSueldo(emp,emp->horasTrabajadas*180);
    }
    else if(emp->horasTrabajadas >=177 && emp->horasTrabajadas <=208)
    {
        extras=emp->horasTrabajadas-176;
        auxSueldo=(176*180)+extras*270;
        emp->sueldo=auxSueldo;
        //setterSueldo(emp,extras);
    }
    else if(emp->horasTrabajadas>=209 && emp->horasTrabajadas<=240)
    {
        extrasalcien=emp->horasTrabajadas-208;
        auxSueldo=(176*180)+(31*270)+extrasalcien*360;
        emp->sueldo=auxSueldo;
        //setterSueldo(emp,extrasalcien);
    }
    return emp;
}

Empleado* emp_new(void)
{

    Empleado* returnAux;
    Empleado* aux;
    aux = (Empleado*)calloc(1,sizeof(Empleado));
    if(aux!=NULL)
    {
        returnAux=aux;
    }
    return returnAux;

}

int setterName(Empleado* this, char* name)
{
    strcpy(this->nombre,name);
    return 0;

}

int setterHoras(Empleado* this, char* horas)
{
    this->horasTrabajadas=atoi(horas);
    return 0;

}

int setterId(Empleado* this, char* id)
{
    this->id=atoi(id);
    return 0;

}

int setterSueldo(Empleado* this, int sueldo)
{
    this->sueldo=sueldo;
    return 0;
}

void emp_print(Empleado* this)
{
    printf("%d\t%-15s\t%d\n",this->id,this->nombre,this->horasTrabajadas);
}

void mostrarMuchos(ArrayList* this)
{
    int i;
    void* aux;
    for(i=0; i<this->len(this); i++)
    {
        if(!(i%250))
        {
            system("pause");
        }

        aux=(Empleado*)this->get(this,i);
        emp_print(aux);
    }
    return;
}
