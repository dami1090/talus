#ifndef EMPLEADO_H_INCLUDED
#define EMPLEADO_H_INCLUDED
#include "ArrayList.h"
struct S_Empleado
{
  int id;
  char nombre[128];
  int horasTrabajadas;
  int sueldo;
};
typedef struct S_Empleado Empleado;

void em_calcularSueldo(void* p);

Empleado* emp_new(void);
int setterName(Empleado* this, char* name);
int setterHoras(Empleado* this, char* horas);
int setterId(Empleado* this, char* id);
int setterSueldo(Empleado* this, int sueldo);
void emp_print(Empleado* this);
void mostrarMuchos(ArrayList* this);
#endif // EMPLEADO_H_INCLUDED
