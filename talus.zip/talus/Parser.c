#include "ArrayList.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "Parser.h"
#include "Empleado.h"
int parser_parseEmpleados(char* fileName, ArrayList* listaEmpleados)
{
    int retorno=0;
    char auxName[100],auxID[100],auxHoras[100];
    Empleado* emp;
    Empleado* aux;
    FILE* pFile;

    pFile=fopen(fileName,"r");

    if(pFile!=NULL)
    {
        fscanf(pFile,"%[^,],%[^,],%[^\n]\n",auxID,auxName,auxHoras);
        while(!feof(pFile))
        {
            fscanf(pFile,"%[^,],%[^,],%[^\n]\n",auxID,auxName,auxHoras);
            aux=emp_new();
            if(aux!=NULL)
            {
                emp=aux;
                setterName(emp,auxName);
                setterId(emp,auxID);
                setterHoras(emp,auxHoras);
               listaEmpleados->add(listaEmpleados,emp);

            }
            else
            {
                printf("\nNo hay mas espacio\n");
            }
            retorno=1;
        }
    }
    fclose(pFile);
    return retorno;// OK
}
