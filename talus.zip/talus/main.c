#include <stdio.h>
#include <stdlib.h>
#include "Empleado.h"
#include "ArrayList.h"
#include "Parser.h"

int generarArchivoSueldos(char* fileName,ArrayList* listaEmpleados);

int main()
{
    int i;
    // Definir lista de empleados
    ArrayList* listaEmpleados;
    ArrayList* ListaAux;
    // Crear lista empledos
    ListaAux=al_newArrayList();
    if(ListaAux!=NULL)
    {
        listaEmpleados=ListaAux;

        // Leer empleados de archivo data.csv
        if(parser_parseEmpleados("data.txt",listaEmpleados)==1)
        {
            // Calcular sueldos
            mostrarMuchos(listaEmpleados);
            printf("Calculando sueldos de empleados\n");
            for(i=0;i<listaEmpleados->len(listaEmpleados);i++)
            {
                em_calcularSueldo(listaEmpleados->get(listaEmpleados,i));
               //al_map(listaEmpleados,em_calcularSueldo(listaEmpleados->get(listaEmpleados,i)));
            }


            // Generar archivo de salida
            if(generarArchivoSueldos("sueldos.csv",listaEmpleados)==1)
            {
                printf("Archivo generado correctamente\n");
            }
            else
                printf("Error generando archivo\n");
        }
        else
            printf("Error leyendo empleados\n");
    }

    return 0;
}

int generarArchivoSueldos(char* fileName,ArrayList* listaEmpleados)
{
    int retorno=0;
    FILE *fp;
    Empleado* auxElement;
    int i;
    fp = fopen ( fileName, "w+" );
    if(fp!=NULL)
    {
        for(i=0;i<listaEmpleados->len(listaEmpleados);i++)
        {
            auxElement=(Empleado*)listaEmpleados->get(listaEmpleados,i);
            fprintf(fp,"%d,",auxElement->id);
            fprintf(fp,"%s,",auxElement->nombre);
            fprintf(fp,"%d,",auxElement->horasTrabajadas);
            fprintf(fp,"%d\n",auxElement->sueldo);
        }
        retorno=1;
    }
    else
    {
        printf("\nNo pudo crearse el archivo\n");
    }
    fclose ( fp );

 	return retorno;
}
